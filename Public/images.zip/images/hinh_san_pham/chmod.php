<?php
@chmod("backup",0777);
 ?>